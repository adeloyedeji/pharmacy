<div class="mobile-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mobile-menu">
                    <nav id="dropdown">
                        <ul>
                           <li><a href="{{route('index')}}">Home</a></li>
                           <li><a href="{{route('about')}}">About us</a></li>
                           <li><a href="#">Services</a></li>
                           <li><a href="{{route('blog')}}">Blog</a></li>
                           <li><a href="#">Restaurant & Bakery</a></li>
                           <li><a href="#">Career & Recruitment</a></li>
                            <li><a href="{{route('contact')}}">contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>