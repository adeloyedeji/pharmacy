<div id="sticker" class="h2_main-menu_area">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="small-logo"><a href="{{route('index')}}"><img src="{{URL::to('assets/img/logos/mainlogo.png')}}" alt=""></a></div>
                <div class="menu-area">
                    <nav class="main-menu">
                        <ul>
                            <li><a href="{{route('index')}}">Home</a></li>

                            <li><a href="{{route('about')}}">About us</a>
                                
                            </li>
                            
                            <li><a href="#">Services</a></li>

                            <li><a href="{{route('blog')}}">Blog & Media</a></li>

                            <li><a href="#">Restaurant & Bakery</a></li>

                            <li><a href="#">CAREERS & RECRUITMENT</a></li>
                            
                            


                            <li><a href="{{route('contact')}}">Contact us</a>

                               
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>