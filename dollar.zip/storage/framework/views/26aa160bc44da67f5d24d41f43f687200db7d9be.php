<div class="h-2-sliders all-navs">
    <div class="single-h2-slide s171">
        <img src="assets/img/slider/h17/1.jpg" alt="" />
        <div class="slider-text">
            <h2>Best Quality <br> <span>Medications</span> </h2>
            <h3>at Low Prices</h3>
            <a href="#">purchase now</a>
        </div>
    </div>
    <div class="single-h2-slide s172">
        <img src="assets/img/slider/h17/2.jpg" alt="" />
        <div class="slider-text">
            <h2>Quality Service</h2>
            <h3>for all your health needs</h3>
            <a href="#">purchase now</a>
        </div>
    </div>
    <div class="single-h2-slide s173">
        <img src="assets/img/slider/h17/3.jpg" alt="" />
        <div class="slider-text">
            <h3>medication packing</h3>
            <h2>Pharmacy <br> Solutions</h2>
            <a href="#">purchase now</a>
        </div>
    </div>
</div>