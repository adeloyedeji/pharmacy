<div class="mobile-menu-area">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="mobile-menu">
                    <nav id="dropdown">
                        <ul>
                            <li><a href="index.html">Home</a>
                                <ul>
                                    <li><a href="index.html" class="mega-title"> BiCycle Store </a></li>
                                    <li><a href="index-2.html" class="mega-title"> Shopping Mall Store </a></li>
                                    <li><a href="index-3.html" class="mega-title"> BackPacks Store </a></li>
                                    <li> <a href="index-4.html" class="mega-title"> Bakery Store </a></li>
                                    <li><a href="index-5.html" class="mega-title"> T-Shirt Store </a></li>
                                    <li><a href="index-6.html" class="mega-title"> Tools Hardware Store </a></li>
                                    <li><a href="index-7.html" class="mega-title"> Baby Store </a></li>
                                    <li><a href="index-8.html" class="mega-title"> Health Store </a></li>
                                    <li> <a href="index-9.html" class="mega-title"> Jewelry Store </a> </li>
                                    <li>  <a href="index-10.html" class="mega-title"> Application Store </a> </li>
                                    <li><a href="index-11.html" class="mega-title"> Lingeries Store </a></li>
                                    <li><a href="index-12.html" class="mega-title"> HighTech Store </a></li>
                                    <li><a href="index-13.html" class="mega-title"> Office Store </a></li>
                                    <li><a href="index-14.html" class="mega-title"> Fashion Jemiz Store </a></li>
                                    <li> <a href="index-15.html" class="mega-title"> GameWorld Store </a></li>
                                    <li>  <a href="index-16.html" class="mega-title"> Sneaker Store </a> </li>
                                    <li> <a href="index-17.html" class="mega-title"> Drug Store </a> </li>
                                    <li> <a href="index.html" class="mega-title"> Fashion Store </a> </li>
                                </ul>
                            </li>
                            <li><a href="shop.html">Women</a>
                                <ul>
                                    <li><a href="shop-list.html">Dresses</a>
                                        <ul>
                                            <li><a href="shop.html">Cocktail</a></li>
                                            <li><a href="shop-list.html">Day</a></li>
                                            <li><a href="shop.html">Evening</a></li>
                                            <li><a href="shop-list.html">T-Shirts</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="shop.html">Clothing</a>
                                        <ul>
                                            <li><a href="shop.html">Sports</a></li>
                                            <li><a href="shop-list.html">run</a></li>
                                            <li><a href="shop.html">sandals</a></li>
                                            <li><a href="shop-list.html">Books</a></li>
                                            <li><a href="shop.html">T-Shirts</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li><a href="shop.html">Men</a>
                                <ul>
                                    <li><a href="shop.html">Sports</a></li>
                                    <li><a href="shop.html">run</a></li>
                                    <li><a href="shop.html">sandals</a></li>
                                    <li><a href="shop.html">Books</a></li>
                                    <li><a href="shop.html">T-Shirts</a></li>
                                </ul>
                            </li>
                            <li><a href="shop.html">Shop</a>
                                <ul>
                                    <li><a href="shop.html">Grid View</a></li>
                                    <li><a href="shop-list.html">List View</a></li>
                                    <li><a href="cart.html">Cart page</a></li>
                                    <li><a href="wishlist.html">wishlist page</a></li>
                                    <li><a href="checkout.html">checkout page</a></li>
                                    <li><a href="single-product.html">single product page</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Other Pages</a>
                                <ul>
                                    <li><a href="shop.html">shop page</a></li>
                                    <li><a href="single-product.html">single product page</a></li>
                                    <li><a href="cart.html">cart page</a></li>
                                    <li><a href="checkout.html">checkout page</a></li>
                                    <li><a href="blog.html">blog page</a></li>
                                    <li><a href="single-blog.html">single blog page</a></li>
                                    <li><a href="about.html">About page</a></li>
                                    <li><a href="404.html">404 page</a></li>
                                    <li><a href="contact.html"> contact page </a></li>
                                </ul>
                            </li>
                            <li><a href="contact-us.html">contact</a></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>