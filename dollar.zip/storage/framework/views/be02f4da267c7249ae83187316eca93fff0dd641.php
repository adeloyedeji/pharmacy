<?php $__env->startSection('title'); ?>

    Order Details

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="navy-blue">
                            <h4 class="title">Order Details</h4>
                            <p class="category">Products in your order.</p>
                        </div>
                        <div class="card-content table-responsive">
                            <table class="table">
                                <thead class="text-primary">
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->qty); ?></td>
                                    <td>₦<?php echo e(number_format($product->price)); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td colspan="2"><div class="x4 text-light text-right">Total</div></td>
                                    <td><div class="x4 text-light text-left">₦<?php echo e(number_format($order->amount)); ?></div></td>
                                </tr>

                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card-content table-responsive">
                        <table class="table">
                            <thead class="text-primary">
                            <th>Date Ordered</th>
                            <th>Payment Status</th>
                            <th>Payment Method</th>
                            <th>Delivery Status</th>
                            </thead>
                            <tbody>

                                <tr>
                                    <td><?php echo e($order->created_at->toDayDateTimeString()); ?></td>
                                    <td><?php echo e($order->status); ?></td>
                                    <td><?php echo e($order->payment_type); ?></td>
                                    <td><?php echo e($order->delivery_status ? 'Delivered' : 'Undelivered'); ?></td>
                                </tr>


                            </tbody>
                        </table>
                    </div>
                </div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>