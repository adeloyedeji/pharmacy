<header>
    <!-- header top area start -->
    <div class="header_top_area">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 col-md-3 col-lg-3">
                    <p> <i class="fa fa-phone"></i> hotline: 01922262289</p>
                </div>
                <div class="col-sm-8 col-md-9 col-lg-9">
                    <div class="right-menus">
                        <ul>
                            <li><a href="#"><img alt="" src="assets/img/lng/english.png"> English <i class="fa fa-angle-down"></i> </a>
                                <ul class="sub-lng">
                                    <li><a href="#"> <img alt="" src="assets/img/lng/english.png"> <span>English</span> </a></li>
                                    <li><a href="#"> <img alt="" src="assets/img/lng/french.png"> <span>French</span> </a></li>
                                    <li><a href="#"> <img alt="" src="assets/img/lng/german.png"> <span>German</span> </a></li>
                                </ul>
                            </li>
                            <li><a href="#">USD <i class="fa fa-angle-down"></i></a>
                                <ul class="sub-lng tk">
                                    <li><a href="#"> <span>EUR</span> </a></li>
                                    <li><a href="#"> <span>USD</span> </a></li>
                                    <li><a href="#"> <span>EUR</span> </a></li>
                                </ul>
                            </li>
                            <li><a href="#"><span> <i class="fa fa-unlock-alt"></i></span> Login  </a>
                                <div class="block-content">
                                    <ul class="form-list">
                                        <li>
                                            <label>Email Address<em>*</em></label>
                                            <input type="text" class="input-text">
                                        </li>
                                        <li>
                                            <label>Password<em>*</em></label>
                                            <input type="password" class="input-text">
                                        </li>
                                        <li><span class="required">* Required Fields</span></li>
                                    </ul>
                                    <div class="action-forgot">
                                        <div class="login_forgotpassword">
                                            <p><a href="#">Forgot Your Password?</a></p>
                                            <p><span>Don't have an account?</span>
                                                <a class="create-account-link-wishlist" href="#" title="Sign Up">Sign Up</a>
                                            </p>
                                        </div>
                                        <div class="actions">
                                            <button type="submit" class="button"><span><span>Login</span></span></button>
                                        </div>
                                    </div>
                                </div>
                            </li>
                            <li><a href="#"><span><i class="fa fa-key"></i></span>  Register</a></li>
                            <li><a href="#"><span> <i class="fa fa-heart"></i> </span>Wishlist</a></li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- header main area start -->
    <div class="header_main_area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-3 col-lg-3">
                    <div class="h2-logo">
                        <a href="index.html"><img src="assets/img/logos/logo2.png" alt="" /></a>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="h2-cat-search">
                        <div class="em-category-search">
                            <form action="#">
                                <div class="form-search cate_search">
                                    <div class="input_cat hidden-xs">
                                        <div class="catsearch-dropdown over">
                                            <span class="current">&nbsp;&nbsp;&nbsp; All Categories</span>
                                            <ul >
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;All Categories </a></li>
                                                <li><a href="#">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Furniture</a></li>
                                                <li><a href="#">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Living Room</a></li>
                                                <li><a href="#">  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Bedroom</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Electronics </a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cell Phones</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cameras</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Accessories</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Digital Cameras</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Computers</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Build Your Own</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Laptops</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hard Drives</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Monitors</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; RAM / Memory</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cases</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Processors</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Peripherals</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fashion</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Dresses</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Backpacks</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Shoes</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; T-Shirt</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Baby</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Computers</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Cell Phones</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Application</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lingerie</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Drug</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Office</a></li>
                                                <li><a href="#"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Lamp-Chair</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="text-search">
                                        <input type="search" placeholder="Search entire store here..." class="input-text required-entry" value="">
                                        <button class="button" title="Search" type="submit"><span><span>Search</span></span></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-3 col-lg-3">
                    <div class="cart-area">
                        <div class="main-cart-area">
                            <div class="cart-icon">
                                <a href="#">
                                    <i class="fa fa-shopping-cart"></i>My Cart: 2
                                </a>
                            </div>
                            <div class="cart-sub">
                                <div class="all_carts_item">
                                    <div class="row mini-cart-item ">
                                        <a href="#" class="cart_list_product_img">
                                            <img class="attachment-shop_thumbnail" src="assets/img/cart/1.jpg" alt="04">
                                        </a>
                                        <div class="mini-cart-info">
                                            <a href="#" class="cart_list_product_title">bicy0004 Sky Print</a>
                                            <div class="cart_list_product_quantity">2 x <span class="amount">$40.00</span></div>
                                        </div>
                                        <a title="Remove this item" class="remove" href="#"><i class="fa fa-trash-o"></i></a>
                                    </div>
                                    <div class="row mini-cart-item ">
                                        <a href="#" class="cart_list_product_img">
                                            <img class="attachment-shop_thumbnail" src="assets/img/cart/2.jpg" alt="04">
                                        </a>
                                        <div class="mini-cart-info">
                                            <a href="#" class="cart_list_product_title">Print Night Sky </a>
                                            <div class="cart_list_product_quantity">3 x <span class="amount">$140.00</span></div>
                                        </div>
                                        <a title="Remove this item" class="remove" href="#"><i class="fa fa-trash-o"></i></a>
                                    </div>
                                </div>
                                <div class="minicart_total_checkout">
                                    Subtotal<span><span class="amount">$80.00</span></span>
                                </div>
                                <div class="btn-mini-cart inline-lists">
                                    <a class="button btn-viewcart" href="shopping-cart.html">View Cart</a>
                                    <a title="Checkout" class="button btn-checkout" href="checkout.html">Checkout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- header main area end -->
</header>