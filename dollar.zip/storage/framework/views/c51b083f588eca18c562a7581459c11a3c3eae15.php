<?php $__env->startSection('title'); ?>

    My Prescriptions

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header" data-background-color="navy-blue">
                            <i class="material-icons">local_pharmacy</i>
                        </div>
                        <div class="card-content">
                            <p class="category">Cleared Prescriptions</p>
                            <h3 class="title"><?php echo e($prescriptions->count()); ?></h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">local_pharmacy</i>
                                <a href="<?php echo e(route('prescription.create')); ?>">Request Prescription</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header" data-background-color="red">
                            <i class="material-icons">local_pharmacy</i>
                        </div>
                        <div class="card-content">
                            <p class="category">Pending Prescriptions</p>
                            <h3 class="title"><?php echo e($pending_prescriptions->count()); ?></h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">local_pharmacy</i>
                                <a href="#pablo">view all prescriptions</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="navy-blue">
                            <h4 class="title">Recent Pending Prescriptions</h4>
                            <p class="category">Showing last 4 pending Prescriptions</p>
                        </div>
                        <div class="card-content table-responsive">
                            <table class="table table-hover">
                                <thead class="text-warning">
                                <th>S/N</th>
                                <th>Title</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                </thead>
                                <tbody>
                                <?php if($prescriptions->count() == 0): ?>
                                    <tr><td>No Prescription Record Found...</td></tr>
                                <?php else: ?>

                                    <?php $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($prescription->title); ?></td>
                                            <td>₦<?php echo e(number_format($prescription->amount)); ?></td>
                                            <td><?php echo e(!$prescription->pharm_response ? 'Pending' : 'Done'); ?></td>
                                            <td><?php echo e($prescription->created_at->toDayDateTimeString()); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12">
                    <div class="card">
                        <div class="card-header" data-background-color="red">
                            <h4 class="title">Recent Debit Wallet Activity</h4>
                            <p class="category">Showing last 4 Debit Wallet Transaction</p>
                        </div>
                        <div class="card-content table-responsive">
                            <table class="table table-hover">
                                <thead class="text-warning">
                                <th>S/N</th>
                                <th>Title</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                                </thead>
                                <tbody>

                                <?php if($pending_prescriptions->count() == 0): ?>
                                    <tr><td>No pending prescription Record Found...</td></tr>
                                <?php else: ?>

                                    <?php $__currentLoopData = $pending_prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$pending_prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($pending_prescription->title); ?></td>
                                            <td>₦<?php echo e(number_format($pending_prescription->amount)); ?></td>
                                            <td><?php echo e(!$pending_prescription->pharm_response ? 'Pending' : 'Done'); ?></td>
                                            <td><?php echo e($pending_prescription->created_at->toDayDateTimeString()); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard_main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>