<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- slider area start -->
    <div class="h2_slider_area">
        <div class="container">
            <div class="row">
                <div class="h2-main-slider ">
                    <?php echo $__env->make('partials._categories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="col-sm-12 col-md-9 col-lg-9">
                        <?php echo $__env->make('partials._slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="row">
                            <!-- add area start -->
                            <div class="electronics-bottom-bannar-area">
                                <div class="col-sm-6 col-md-6 col-lg-6">
                                    <a href="#"><img alt="" src="assets/img/all-adds/88.jpg"></a>
                                </div>
                                <div class="col-sm-6  col-md-6 col-lg-6">
                                    <a href="#"><img alt="" src="assets/img/all-adds/89.jpg"></a>
                                </div>
                            </div>


                            <!-- add area end -->
                        </div>
                        <div class="h2-new-arrivals-area">
                            <div class="h2-arviel-title h17t"><h3>Vaccines, Blood &amp; Biologics</h3></div>
                            <div class="clear"></div>
                            <div class="row">
                                <div class="h2-products nrb-next-prev">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/1.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/2.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00</h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/3.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/4.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <h3>$172.00</h3>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/5.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/6.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00</h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/7.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/8.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00 </h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clear"></div>
                        <div class="h2-new-arrivals-area cend-pd">
                            <div class="h2-arviel-title h17t"><h3>Comestics</h3></div>
                            <div class="clear"></div>
                            <div class="row">
                                <div class="h2-products nrb-next-prev">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/9.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/10.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00</h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/11.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/12.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <h3>$172.00</h3>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/13.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/14.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00</h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/1.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/2.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00 </h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="clear"></div>
                        <div class="h2-new-arrivals-area cend-pn">
                            <div class="h2-arviel-title h17t"><h3>Vitamins &amp; Supplements</h3></div>
                            <div class="clear"></div>
                            <div class="row">
                                <div class="h2-products nrb-next-prev">
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/1.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/2.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00</h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/3.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/4.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <h3>$172.00</h3>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/5.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/6.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00</h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12">
                                        <div class="t-all-product-info">
                                            <div class="p-sign">new</div>
                                            <div class="t-product-img">
                                                <a href="#">
                                                    <img src="assets/img/products/h17/7.jpg" alt="" />
                                                    <img class="second-img" src="assets/img/products/h17/8.jpg" alt="" />
                                                </a>
                                            </div>
                                            <div class="tab-p-info">
                                                <a href="#">Bike Hardtail MTB </a>
                                                <h3>$172.00 </h3>
                                                <div class="star">
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                    <i class="fa fa-star-half-o"></i>
                                                </div>
                                                <div class="al-btns">
                                                    <button type="button" title="Add to Cart" class="button btn-cart"><span> <i class="fa fa-shopping-cart"></i> Add to Cart</span></button>
                                                    <ul class="add-to-links">
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-eye"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-retweet"></i></a></li>
                                                        <li><a href="#" class="link-wishlist" title="Wishlist"><i class="fa fa-heart-o"></i></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- footer product area  -->
            <?php echo $__env->make('partials._footer_product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <!-- slider area End -->



    <!--home blog area start -->
    <div class="h8-blog-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="new-title-wrap">
                        <div class="h2-arviel-title h17b"><h3>From Our Blog </h3></div>
                    </div>
                </div>
                <div class="col-sm-6  col-md-6 col-lg-6">
                    <div class="singl-h-blog">
                        <div class="em-blog-time">
                            <p class="em-blog-date">7</p>
                            <p class="em-blog-month">Oct</p>
                        </div>
                        <div class="h-b-img">
                            <a href="#"><img src="assets/img/blog/5.jpg" alt="" /></a>
                        </div>
                        <div class="h-blog-info">
                            <h2><a href="#">Pineapples, Mermaids and…</a></h2>
                            <p>Boutique festival Secret Garden went down in Sydney’s Camden over the weekend, and all the free-spirited kids came out to…</p>
                            <a href="#"><span><i class="fa fa-angle-double-right"></i></span>Read more</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="singl-h-blog">
                        <div class="em-blog-time">
                            <p class="em-blog-date">6</p>
                            <p class="em-blog-month">Oct</p>
                        </div>
                        <div class="h-b-img">
                            <a href="#"><img src="assets/img/blog/6.jpg" alt="" /></a>
                        </div>
                        <div class="h-blog-info">
                            <h2><a href="#">New Layer Navigation…</a></h2>
                            <p>Boutique festival Secret Garden went down in Sydney’s Camden over the weekend, and all the free-spirited kids came out to…</p>
                            <a href="#"><span><i class="fa fa-angle-double-right"></i></span>Read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--home blog area end -->

<?php $__env->stopSection(); ?>









<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>