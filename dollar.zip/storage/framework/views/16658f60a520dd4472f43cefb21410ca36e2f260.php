<div class="h-2-sliders all-navs">
    <div class="single-h2-slide s171">
        <img src="<?php echo e(URL::to('assets/img/slider/slide1.jpg')); ?>" alt="" />

    </div>
    <div class="single-h2-slide s172">
        <img src="<?php echo e(URL::to('assets/img/slider/slide2.jpg')); ?>" alt="" />

    </div>
    <div class="single-h2-slide s173">
        <img src="<?php echo e(URL::to('assets/img/slider/slide3.jpg')); ?>" alt="" />

    </div>
</div>