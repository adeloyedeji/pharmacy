<?php $__env->startSection('title'); ?>
    Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Cart area Start -->
    <div class="main_cart_area">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="main_cart">
                        <div class="cart_heading_top">
                            <h2>Shopping-cart summary
                                <span> Your shopping cart contains:<span><?php echo e(Cart::count()); ?> products</span> </span>
                            </h2>
                        </div>
                    </div>
                    <div class="wishlist-content cart-arae ">
                        <form action="#">
                            <div class="table-content table-responsive">
                                <table>
                                    <thead>
                                    <tr>
                                        <th class="product-thumbnail">Image</th>
                                        <th class="product-name">Product</th>
                                        <th class="product-price">Price</th>
                                        <th class="product-quantity">Quantity</th>
                                        <th class="product-subtotal">Total</th>
                                        <th class="product-remove">Remove</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="product-thumbnail"><a href="#"><img src="<?php echo e($cart->model->small1); ?>" alt="" /></a></td>
                                        <td class="product-name"><a href="#"><?php echo e($cart->name); ?></a></td>
                                        <td class="product-price"><span class="amount">₦<?php echo e(number_format($cart->price)); ?></span></td>
                                        <td class="product-quantity"><input type="number" value="1" /></td>
                                        <td class="product-subtotal">₦<?php echo e(Cart::subtotal()); ?></td>
                                        <td class="product-remove"><a href="<?php echo e(route('cart.delete', ['id' =>$cart->rowId])); ?>"><i class="fa fa-times"></i></a></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>

                        </form>
                        <div class="col-md-8 col-sm-7 col-md-offset-2">
                            <div class="buttons-cart">
                                <a class="pull-left" href="<?php echo e(route('index')); ?>">Continue Shopping </a>

                                <a class="pull-right" href="<?php echo e(route('checkout')); ?>">Proceed to checkout</a>
                            </div>

                        </div>
                    </div>

                </div>


            </div>
        </div>
    </div>
    <!-- Cart area End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>