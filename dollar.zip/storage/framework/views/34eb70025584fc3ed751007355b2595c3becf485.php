<div class="col-sm-12 col-md-3 col-lg-3 hidden-sm hidden-xs ">
    <div class="h-16">
        <div class="h2-left-cat">
            <h2 class="left-crt-title">Cateogry</h2>
            <div class="h16-menu">
                <nav>
                    <div class="left-cart-menu">
                        <ul>
                            <li> <i class="fa fa-car"></i> <a href="#"> Women’s Clothing </a> <span><i class="fa fa-caret-right"></i></span>
                                <ul class="cat-sb">
                                    <li><a href="#">I-phone5 Clothing</a></li>
                                    <li><a href="#">Nokia 007 Handbags</a></li>
                                    <li><a href="#">Eyeglasses technology</a></li>
                                    <li><a href="#">Shoes man calculations</a></li>
                                    <li><a href="#">Book stall forever</a></li>
                                    <li><a href="#">computer best soft</a></li>
                                    <li><a href="#">Bangladesh country</a></li>
                                </ul>
                            </li>
                            <li> <i class="fa fa-heart"></i> <a href="#"> Men’s Clothing </a> <span><i class="fa fa-caret-right"></i></span>
                                <ul class="cat-sb">
                                    <li><a href="#">I-phone5 Clothing</a></li>
                                    <li><a href="#">Nokia 007 Handbags</a></li>
                                    <li><a href="#">Eyeglasses technology</a></li>
                                    <li><a href="#">Shoes man calculations</a></li>
                                    <li><a href="#">Book stall forever</a></li>
                                    <li><a href="#">computer best soft</a></li>
                                    <li><a href="#">Bangladesh country</a></li>
                                </ul>
                            </li>
                            <li> <i class="fa fa-university"></i> <a href="#"> Eyeglasses </a> <span><i class="fa fa-caret-right"></i></span>
                                <ul class="cat-sb">
                                    <li><a href="#">I-phone5 Clothing</a></li>
                                    <li><a href="#">Nokia 007 Handbags</a></li>
                                    <li><a href="#">Eyeglasses technology</a></li>
                                    <li><a href="#">Shoes man calculations</a></li>
                                    <li><a href="#">Book stall forever</a></li>
                                    <li><a href="#">computer best soft</a></li>
                                    <li><a href="#">Bangladesh country</a></li>
                                </ul>
                            </li>
                            <li> <i class="fa fa-camera"></i> <a href="#"> Steel  Watches </a> <span><i class="fa fa-caret-right"></i></span>
                                <ul class="cat-sb">
                                    <li><a href="#">I-phone5 Clothing</a></li>
                                    <li><a href="#">Nokia 007 Handbags</a></li>
                                    <li><a href="#">Eyeglasses technology</a></li>
                                    <li><a href="#">Shoes man calculations</a></li>
                                    <li><a href="#">Book stall forever</a></li>
                                </ul>
                            </li>
                            <li> <i class="fa fa-video-camera"></i> <a href="#"> Handbags </a> <span><i class="fa fa-caret-right"></i></span>
                                <ul class="cat-sb">
                                    <li><a href="#">I-phone5 Clothing</a></li>
                                    <li><a href="#">Nokia 007 Handbags</a></li>
                                    <li><a href="#">Eyeglasses technology</a></li>
                                    <li><a href="#">Shoes man calculations</a></li>
                                </ul>
                            </li>
                            <li> <i class="fa fa-desktop"></i>   <a href="#"> desktop </a> </li>
                            <li> <i class="fa fa-rss"></i>  <a href="#"> Shoes  </a>  </li>
                            <li> <i class="fa fa-gift"></i>   <a href="#"> gift  </a> </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <div class="h2-testimuial">
        <div class="singl-tesimonial">
            <div class="s-test-img">
                <img src="assets/img/testi2.png" alt="">
            </div>
            <div class="s-test-infos">
                <h3>Nirob khan </h3>
                <p class="text-testi"><i class="fa fa-quote-left"></i>You can change the visual appearance of almost every                                element of the theme.</p>
            </div>
        </div>
        <div class="singl-tesimonial">
            <div class="s-test-img">
                <img src="assets/img/testi3.png" alt="">
            </div>
            <div class="s-test-infos">
                <h3>salim rana </h3>
                <p class="text-testi"><i class="fa fa-quote-left"></i>You can change the visual appearance of almost every                                element of the theme.</p>
            </div>
        </div>
    </div>

    <div class="h2-left-cat nra">
        <h2 class="left-crt-title">Best Sellers</h2>
        <div class="b-p-area">
            <div class="product-sale-of">
                <div class="s-of-p-img">
                    <a href="#">
                        <img class="min-img" src="assets/img/products/thumb/23.jpg" alt="">
                        <img class="other-img" src="assets/img/products/thumb/24.jpg" alt="">
                    </a>
                </div>
                <div class="s-of-p-info">
                    <div class="tab-p-info">
                        <a href="#"> Apple iMac ME045 </a>
                        <div class="star">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-half-o"></i>
                        </div>
                        <h3>$872.00 </h3>
                    </div>
                </div>
            </div>
            <div class="product-sale-of">
                <div class="s-of-p-img">
                    <a href="#">
                        <img class="min-img" src="assets/img/products/thumb/25.jpg" alt="">
                        <img class="other-img" src="assets/img/products/thumb/26.jpg" alt="">
                    </a>
                </div>
                <div class="s-of-p-info">
                    <div class="tab-p-info">
                        <a href="#"> Apple iMac ME045 </a>
                        <div class="star">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-half-o"></i>
                        </div>
                        <h3>$872.00 </h3>
                    </div>
                </div>
            </div>
            <div class="product-sale-of last-pd">
                <div class="s-of-p-img">
                    <a href="#">
                        <img class="min-img" src="assets/img/products/thumb/27.jpg" alt="">
                        <img class="other-img" src="assets/img/products/thumb/28.jpg" alt="">
                    </a>
                </div>
                <div class="s-of-p-info">
                    <div class="tab-p-info">
                        <a href="#"> Apple iMac ME045 </a>
                        <div class="star">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-half-o"></i>
                            <i class="fa fa-star-half-o"></i>
                        </div>
                        <h3>$872.00 </h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- add area -->
    <div class="all-h17-left-add">
        <div class="new-adds electronics-bottom-bannar-area">
            <a href="#"><img src="assets/img/all-adds/90.jpg" alt=""></a>
        </div>

        <div class="new-adds electronics-bottom-bannar-area hidden-md">
            <a href="#"><img src="assets/img/all-adds/91.jpg" alt=""></a>
        </div>
        <div class="img-banner-small hidden-md">
            <div class="banner-img  b-stripe">
                <a href="#">
                    <img src="assets/img/all-adds/93.jpg" alt="" class="img-responsive">
                    <span class="b-line-9 b-position-1">&nbsp;</span>
                    <span class="b-line-9 b-position-2">&nbsp;</span>
                    <span class="b-line-9 b-position-3">&nbsp;</span>
                    <span class="b-line-9 b-position-4">&nbsp;</span>
                    <span class="b-line-9 b-position-5">&nbsp;</span>
                    <span class="b-line-9 b-position-6">&nbsp;</span>
                    <span class="b-line-9 b-position-7">&nbsp;</span>
                    <span class="b-line-9 b-position-8">&nbsp;</span>
                    <span class="b-line-9 b-position-9">&nbsp;</span>
                </a>
            </div>
        </div>
    </div>
    <!-- add area -->
</div>